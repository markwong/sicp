// chapter=4 
install_javascript_number_package();
