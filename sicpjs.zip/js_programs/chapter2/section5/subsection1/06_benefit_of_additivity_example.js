// chapter=4 
install_rational_package();

const r1 = make_rational(1, 3);
const r2 = make_rational(2, 5);

add(r1, r2);
