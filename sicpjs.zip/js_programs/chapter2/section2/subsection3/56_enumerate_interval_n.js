const n = 6;
