dot_product(list(1, 2), list(3, 4));
