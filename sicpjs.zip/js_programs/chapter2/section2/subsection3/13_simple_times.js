function times(x, y) {
    return x * y;
}
