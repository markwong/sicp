import { beside } from 'rune';

// function split to be written by student
const right_split = split(beside, below);
const up_split = split(below, beside);
