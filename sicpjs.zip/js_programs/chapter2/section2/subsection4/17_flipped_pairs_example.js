show(flipped_pairs(heart));
