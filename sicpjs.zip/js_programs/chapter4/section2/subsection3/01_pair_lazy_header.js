const my_pair_lazy = `
