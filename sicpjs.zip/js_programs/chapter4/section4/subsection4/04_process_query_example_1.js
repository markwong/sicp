parse_query_verbose('assert(son("Adam", "Cain"))');
parse_query_verbose('son("Adam", x)');
