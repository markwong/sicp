parse("'hello world';");
