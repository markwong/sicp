const my_block = parse("{ 1; true; 45; }");
display(is_block(my_block));
display(block_body(my_block));
