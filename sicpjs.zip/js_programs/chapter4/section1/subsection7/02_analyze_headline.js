// functions from SICP JS 4.1.7
